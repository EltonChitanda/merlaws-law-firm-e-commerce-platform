<nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm sticky-top">
    <div class="container">
        <a class="navbar-brand" href="/www.merlaws.com/index.php">
            <img src="/www.merlaws.com/image/logo.webp" alt="MerLaws" height="40">
            <span class="ms-2 fw-bold text-danger">MerLaws</span>
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item">
                    <a class="nav-link" href="/www.merlaws.com/index.php">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="/www.merlaws.com/our-services.php">Our Services</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="/www.merlaws.com/about-us.php">About Us</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="/www.merlaws.com/contact-us.php">Contact Us</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link btn btn-outline-danger ms-2 px-3" href="/www.merlaws.com/app/login.php">
                        <i class="fas fa-sign-in-alt me-1"></i> Client Login
                    </a>
                </li>
                <li class="nav-item" style="display: block !important; visibility: visible !important;">
                    <a class="nav-link btn btn-danger text-white ms-2 px-3" href="/www.merlaws.com/app/register.php" style="display: inline-block !important; visibility: visible !important;">
                        <i class="fas fa-user-plus me-1"></i> Register
                    </a>
                </li>
            </ul>
        </div>
    </div>
</nav>
